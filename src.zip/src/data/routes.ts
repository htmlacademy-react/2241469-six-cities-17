export enum PathRoutes{
    MAIN = '/',
    LOGIN = '/login',
    FAVORITES = '/favorites',
    OFFER = '/offer',
    OFFERID = ':id',
    NOTFOUND = '*'
}
