import { ChangeEvent, Fragment, useState } from 'react';
import { COUNT_CHARACTER, StarTitles } from '../../data/const';
import { useAppSelector } from '../../hooks';
import { PathRoutes } from '../../data/routes';
import { ReviewToSend } from '../../data/types/offer';


type CommentFormProps = {
  onFormSubmit: (commentData: ReviewToSend) => Promise<void>;
}

function CommentForm({onFormSubmit}: CommentFormProps): JSX.Element {


  const currentOffer = useAppSelector((state) => state.currentOffer);

  const [formData, setFormData] = useState({
    id: currentOffer?.id,
    rating: 0,
    comment: ''

  } as ReviewToSend);

  const isSubmitDisabled = !formData.rating || formData.comment.length < 50;


  const handleReviewChange = (e: ChangeEvent<HTMLTextAreaElement>) =>{
    setFormData((prev)=>({
      ...prev,
      comment: e.target.value
    }));
  };

  const handleRatingChange = (e: ChangeEvent<HTMLInputElement>) =>{
    setFormData((prev)=>({
      ...prev,
      rating: Number(e.target.value)
    }));
  };

  const handleSubmitForm = (e: ChangeEvent<HTMLFormElement>) =>{
    e.preventDefault();
    onFormSubmit(formData);
    setFormData((prev)=>({
      ...prev,
      rating: 0,
      comment:'',
    }));
  };

  return(
    <form onSubmit={handleSubmitForm} className="reviews__form form" action={`${PathRoutes.OFFER}/${currentOffer?.id}`} method="post">

      <label className="reviews__label form__label" htmlFor="review">Your review</label>
      <div className="reviews__rating-form form__rating">
        {Object.entries(StarTitles).map((star) => (
          <Fragment key={star[0]}>
            <input className="form__rating-input visually-hidden" name="rating" value={star[0]} id={`${star[0]}-stars`} type="radio"
              onChange={handleRatingChange}
            />
            <label htmlFor={`${star[0]}-stars`} className="reviews__rating-label form__rating-label" title={star[1]}>
              <svg className="form__star-image" width="37" height="33">
                <use xlinkHref="#icon-star"></use>
              </svg>
            </label>
          </Fragment>)
        ).reverse()}
      </div>
      <textarea
        className="reviews__textarea form__textarea"
        id="review"
        name="review"
        placeholder="Tell how was your stay, what you like and what can be improved"
        onChange={handleReviewChange}
        value={formData.comment}
      />
      <div className="reviews__button-wrapper">
        <p className="reviews__help">
        To submit review please make sure to set <span className="reviews__star">rating</span> and describe your stay with at least <b className="reviews__text-amount">{COUNT_CHARACTER} characters</b>.
        </p>
        <button className="reviews__submit form__submit button" type="submit" disabled={isSubmitDisabled}>Submit</button>
      </div>
    </form>
  );
}

export default CommentForm;
