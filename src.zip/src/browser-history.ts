import {createBrowserHistory} from 'history';
const browserHistory = createBrowserHistory();
export default browserHistory;
